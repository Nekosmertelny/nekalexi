export type CefrLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export const CEFR_LEVELS: CefrLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

export interface CuratedWordSpec {
  word: string;
  phonetic: string;
  partOfSpeech: string;
  translation: string;
  exampleEn: string;
  exampleRu: string;
  secondaryExampleEn: string;
  secondaryExampleRu: string;
  cefrLevel: CefrLevel;
  imageUrl: string;
}

export interface CuratedDeckSpec {
  key: string;
  title: string;
  description: string;
  category: string;
  cefrLevel: CefrLevel;
  words: CuratedWordSpec[];
}

export const STARTER_WORD_IMAGES: Record<string, string> = {
  // A1
  morning:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/ea/Spring_Lake%2C_New_Jersey_Beach_at_Sunrise.jpg/960px-Spring_Lake%2C_New_Jersey_Beach_at_Sunrise.jpg',
  breakfast:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/75/Breakfast_at_the_Black_Bear_Diner.jpg/960px-Breakfast_at_the_Black_Bear_Diner.jpg',
  family:
    'https://api.openverse.org/v1/images/a4903ab6-ca64-4a4a-bec8-f52e3b166ed1/thumb/',
  happy:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0f/Little_kid_smiling..jpg/960px-Little_kid_smiling..jpg',
  travel:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c0/Suitcase1.jpg/960px-Suitcase1.jpg',
  friend:
    'https://api.openverse.org/v1/images/49a964f1-9eb2-45be-8ea2-f8e3b867ad2b/thumb/',

  // A2
  improve:
    'https://api.openverse.org/v1/images/24f69105-f322-42be-9575-ad02c38f7e57/thumb/',
  schedule:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/ed/Kalender_Indonesia.jpg/960px-Kalender_Indonesia.jpg',
  decide:
    'https://api.openverse.org/v1/images/5f62bcd4-6ac9-41f6-9651-24e10988b0c3/thumb/',
  comfortable:
    'https://api.openverse.org/v1/images/8155689d-7a5c-466e-926a-b50f4a48c48c/thumb/',
  borrow:
    'https://api.openverse.org/v1/images/4be5e095-3b81-4e31-a834-b717ae5acefc/thumb/',
  explain:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e6/A_public_high_school_teacher_in_a_classroom_in_the_United_States_08.jpg/960px-A_public_high_school_teacher_in_a_classroom_in_the_United_States_08.jpg',

  // B1
  experience:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a9/Hiking_to_the_Ice_Lakes._San_Juan_National_Forest%2C_Colorado.jpg/960px-Hiking_to_the_Ice_Lakes._San_Juan_National_Forest%2C_Colorado.jpg',
  opportunity:
    'https://api.openverse.org/v1/images/fbcce663-8be6-4f37-ad8d-4fe588613345/thumb/',
  reliable:
    'https://upload.wikimedia.org/wikipedia/commons/f/f2/Russian_finished_watch_movement.jpg',
  prepare:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/ea/Notebooks.jpg/960px-Notebooks.jpg',
  suggest:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7b/Light-bulbs.jpg/960px-Light-bulbs.jpg',
  'look forward to':
    'https://api.openverse.org/v1/images/f3412955-2fe6-410b-ba9b-d51b9733bc03/thumb/',
  'figure out':
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/66/Jigsaw_puzzle_01_by_Scouten.jpg/960px-Jigsaw_puzzle_01_by_Scouten.jpg',

  // B2
  resilient:
    'https://api.openverse.org/v1/images/757a1ae1-bbc9-4038-94b1-a3a4bf18e1e5/thumb/',
  perspective:
    'https://api.openverse.org/v1/images/e3cee65a-b494-46dd-9fa2-3a0db42182b5/thumb/',
  collaborate:
    'https://api.openverse.org/v1/images/be224b0f-9817-49e7-8402-8198f7f4e126/thumb/',
  efficient:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7d/N700a-Mt.Fuji.jpg/960px-N700a-Mt.Fuji.jpg',
  negotiate:
    'https://api.openverse.org/v1/images/8d589bdf-35bc-4662-ab76-cf60afd3ae18/thumb/',
  sustainable:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/ba/Windmills_D1-D4_%28Thornton_Bank%29.jpg/960px-Windmills_D1-D4_%28Thornton_Bank%29.jpg',

  // C1
  ubiquitous:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/66/Wikipedia_homepage_on_a_large_Android_phone%2C_2015-04-16.jpg/960px-Wikipedia_homepage_on_a_large_Android_phone%2C_2015-04-16.jpg',
  ambiguous:
    'https://api.openverse.org/v1/images/15befa26-0b6b-44db-867a-1e3b365caaab/thumb/',
  scrutinize:
    'https://upload.wikimedia.org/wikipedia/commons/c/c6/Mag_glass_request.jpg',
  pragmatic:
    'https://api.openverse.org/v1/images/83722697-3185-4f57-97fb-db7641693193/thumb/',
  ephemeral:
    'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/96/Sakura_and_Moss_Pink_-_%E6%A1%9C%28%E3%81%95%E3%81%8F%E3%82%89%29%E3%81%A8%E8%8A%9D%E6%A1%9C%28%E3%81%97%E3%81%B0%E3%81%96%E3%81%8F%E3%82%89%29.jpg/960px-Sakura_and_Moss_Pink_-_%E6%A1%9C%28%E3%81%95%E3%81%8F%E3%82%89%29%E3%81%A8%E8%8A%9D%E6%A1%9C%28%E3%81%97%E3%81%B0%E3%81%96%E3%81%8F%E3%82%89%29.jpg',
  eloquent:
    'https://api.openverse.org/v1/images/791bda15-d807-4984-9f27-43d0fa618137/thumb/',
};

export const CURATED_DECKS_CATALOG: CuratedDeckSpec[] = [
  {
    key: 'a1-basics',
    title: 'Базовый старт (A1)',
    description: 'Первые необходимые слова для знакомства, семьи, путешествий и распорядка дня.',
    category: 'Для начинающих',
    cefrLevel: 'A1',
    words: [
      {
        word: 'morning',
        phonetic: '/ˈmɔː.nɪŋ/',
        partOfSpeech: 'noun',
        translation: 'утро',
        exampleEn: 'I drink a cup of coffee every morning.',
        exampleRu: 'Я пью чашку кофе каждое утро.',
        secondaryExampleEn: 'Good morning! How did you sleep?',
        secondaryExampleRu: 'Доброе утро! Как вы спали?',
        cefrLevel: 'A1',
        imageUrl: STARTER_WORD_IMAGES.morning,
      },
      {
        word: 'breakfast',
        phonetic: '/ˈbrek.fəst/',
        partOfSpeech: 'noun',
        translation: 'завтрак',
        exampleEn: 'We usually have breakfast at eight o’clock.',
        exampleRu: 'Обычно мы завтракаем в восемь часов.',
        secondaryExampleEn: 'Fresh fruit is great for breakfast.',
        secondaryExampleRu: 'Свежие фрукты отлично подходят на завтрак.',
        cefrLevel: 'A1',
        imageUrl: STARTER_WORD_IMAGES.breakfast,
      },
      {
        word: 'family',
        phonetic: '/ˈfæm.əl.i/',
        partOfSpeech: 'noun',
        translation: 'семья',
        exampleEn: 'My family lives in a quiet green neighborhood.',
        exampleRu: 'Моя семья живёт в тихом зелёном районе.',
        secondaryExampleEn: 'We spend Sundays together as a family.',
        secondaryExampleRu: 'По воскресеньям мы проводим время всей семьёй.',
        cefrLevel: 'A1',
        imageUrl: STARTER_WORD_IMAGES.family,
      },
      {
        word: 'happy',
        phonetic: '/ˈhæp.i/',
        partOfSpeech: 'adjective',
        translation: 'счастливый, довольный',
        exampleEn: 'She feels happy when her friends visit.',
        exampleRu: 'Она чувствует себя счастливой, когда к ней приходят друзья.',
        secondaryExampleEn: 'We are very happy with our progress.',
        secondaryExampleRu: 'Мы очень довольны нашим прогрессом.',
        cefrLevel: 'A1',
        imageUrl: STARTER_WORD_IMAGES.happy,
      },
      {
        word: 'travel',
        phonetic: '/ˈtræv.əl/',
        partOfSpeech: 'verb',
        translation: 'путешествовать',
        exampleEn: 'I want to travel to Italy next autumn.',
        exampleRu: 'Я хочу поехать в Италию следующей осенью.',
        secondaryExampleEn: 'They often travel by train between cities.',
        secondaryExampleRu: 'Они часто путешествуют между городами на поезде.',
        cefrLevel: 'A1',
        imageUrl: STARTER_WORD_IMAGES.travel,
      },
      {
        word: 'friend',
        phonetic: '/frend/',
        partOfSpeech: 'noun',
        translation: 'друг, подруга',
        exampleEn: 'My best friend helps me practice English.',
        exampleRu: 'Мой лучший друг помогает мне практиковать английский.',
        secondaryExampleEn: 'I met an old friend at the café.',
        secondaryExampleRu: 'Я встретил старого друга в кафе.',
        cefrLevel: 'A1',
        imageUrl: STARTER_WORD_IMAGES.friend,
      },
    ],
  },
  {
    key: 'a2-everyday',
    title: 'Повседневный английский (A2)',
    description: 'Базовые глаголы и прилагательные для общения каждый день.',
    category: 'Повседневное',
    cefrLevel: 'A2',
    words: [
      {
        word: 'improve',
        phonetic: '/ɪmˈpruːv/',
        partOfSpeech: 'verb',
        translation: 'улучшать, совершенствовать',
        exampleEn: 'I read English articles every morning to improve my vocabulary.',
        exampleRu: 'Я читаю статьи на английском каждое утро, чтобы улучшить свой словарный запас.',
        secondaryExampleEn: 'The weather started to improve in the afternoon.',
        secondaryExampleRu: 'Днём погода начала улучшаться.',
        cefrLevel: 'A2',
        imageUrl: STARTER_WORD_IMAGES.improve,
      },
      {
        word: 'schedule',
        phonetic: '/ˈskedʒ.uːl/',
        partOfSpeech: 'noun',
        translation: 'расписание, график',
        exampleEn: 'My work schedule is very busy on Mondays.',
        exampleRu: 'Мой рабочий график очень плотный по понедельникам.',
        secondaryExampleEn: 'We are right on schedule for the train.',
        secondaryExampleRu: 'Мы идём точно по расписанию к поезду.',
        cefrLevel: 'A2',
        imageUrl: STARTER_WORD_IMAGES.schedule,
      },
      {
        word: 'decide',
        phonetic: '/dɪˈsaɪd/',
        partOfSpeech: 'verb',
        translation: 'решать, принимать решение',
        exampleEn: 'We need to decide where to go on vacation this summer.',
        exampleRu: 'Нам нужно решить, куда поехать в отпуск этим летом.',
        secondaryExampleEn: 'She decided to learn a new language.',
        secondaryExampleRu: 'Она решила выучить новый язык.',
        cefrLevel: 'A2',
        imageUrl: STARTER_WORD_IMAGES.decide,
      },
      {
        word: 'comfortable',
        phonetic: '/ˈkʌmf.tə.bəl/',
        partOfSpeech: 'adjective',
        translation: 'удобный, комфортный',
        exampleEn: 'These running shoes are very comfortable for long walks.',
        exampleRu: 'Эти кроссовки очень удобные для долгих прогулок.',
        secondaryExampleEn: 'Make yourself comfortable on the sofa.',
        secondaryExampleRu: 'Устраивайтесь поудобнее на диване.',
        cefrLevel: 'A2',
        imageUrl: STARTER_WORD_IMAGES.comfortable,
      },
      {
        word: 'borrow',
        phonetic: '/ˈbɒr.əʊ/',
        partOfSpeech: 'verb',
        translation: 'одалживать, брать взаймы',
        exampleEn: 'Can I borrow your pen for a minute?',
        exampleRu: 'Можно одолжить твою ручку на минуту?',
        secondaryExampleEn: 'I often borrow interesting books from the local library.',
        secondaryExampleRu: 'Я часто беру интересные книги в местной библиотеке.',
        cefrLevel: 'A2',
        imageUrl: STARTER_WORD_IMAGES.borrow,
      },
      {
        word: 'explain',
        phonetic: '/ɪkˈspleɪn/',
        partOfSpeech: 'verb',
        translation: 'объяснять',
        exampleEn: 'Could you explain this grammar rule one more time?',
        exampleRu: 'Не могли бы вы объяснить это правило грамматики ещё раз?',
        secondaryExampleEn: 'He explained the plan clearly to everyone.',
        secondaryExampleRu: 'Он понятно объяснил план всем.',
        cefrLevel: 'A2',
        imageUrl: STARTER_WORD_IMAGES.explain,
      },
    ],
  },
  {
    key: 'b1-work-travel',
    title: 'Работа, поездки и планы (B1)',
    description: 'Полезные слова среднего уровня для работы, путешествий и переписки.',
    category: 'Общение',
    cefrLevel: 'B1',
    words: [
      {
        word: 'experience',
        phonetic: '/ɪkˈspɪə.ri.əns/',
        partOfSpeech: 'noun',
        translation: 'опыт, впечатление',
        exampleEn: 'Traveling abroad was an unforgettable experience for me.',
        exampleRu: 'Путешествие за границу стало для меня незабываемым опытом.',
        secondaryExampleEn: 'Do you have any experience in customer support?',
        secondaryExampleRu: 'У вас есть опыт работы в поддержке клиентов?',
        cefrLevel: 'B1',
        imageUrl: STARTER_WORD_IMAGES.experience,
      },
      {
        word: 'opportunity',
        phonetic: '/ˌɒp.əˈtʃuː.nə.ti/',
        partOfSpeech: 'noun',
        translation: 'возможность, шанс',
        exampleEn: 'This trip is a great opportunity to practice speaking English.',
        exampleRu: 'Эта поездка — отличная возможность попрактиковать разговорный английский.',
        secondaryExampleEn: 'Do not miss the opportunity to meet new people.',
        secondaryExampleRu: 'Не упустите возможность познакомиться с новыми людьми.',
        cefrLevel: 'B1',
        imageUrl: STARTER_WORD_IMAGES.opportunity,
      },
      {
        word: 'reliable',
        phonetic: '/rɪˈlaɪ.ə.bəl/',
        partOfSpeech: 'adjective',
        translation: 'надёжный',
        exampleEn: 'He is a very reliable friend who always keeps his promises.',
        exampleRu: 'Он очень надёжный друг, который всегда держит свои обещания.',
        secondaryExampleEn: 'We need a reliable internet connection for the call.',
        secondaryExampleRu: 'Нам нужно надёжное интернет-соединение для созвона.',
        cefrLevel: 'B1',
        imageUrl: STARTER_WORD_IMAGES.reliable,
      },
      {
        word: 'prepare',
        phonetic: '/prɪˈpeər/',
        partOfSpeech: 'verb',
        translation: 'готовиться, подготавливать',
        exampleEn: 'I need to prepare for my English test tomorrow.',
        exampleRu: 'Мне нужно подготовиться к завтрашнему тесту по английскому.',
        secondaryExampleEn: 'She helped us prepare dinner for the guests.',
        secondaryExampleRu: 'Она помогла нам приготовить ужин для гостей.',
        cefrLevel: 'B1',
        imageUrl: STARTER_WORD_IMAGES.prepare,
      },
      {
        word: 'suggest',
        phonetic: '/səˈdʒest/',
        partOfSpeech: 'verb',
        translation: 'предлагать (идею)',
        exampleEn: 'I suggest taking a short break before we continue.',
        exampleRu: 'Я предлагаю сделать небольшой перерыв, прежде чем мы продолжим.',
        secondaryExampleEn: 'What restaurant do you suggest for tonight?',
        secondaryExampleRu: 'Какой ресторан ты посоветуешь на сегодняшний вечер?',
        cefrLevel: 'B1',
        imageUrl: STARTER_WORD_IMAGES.suggest,
      },
      {
        word: 'look forward to',
        phonetic: '/lʊk ˈfɔː.wəd tuː/',
        partOfSpeech: 'phrasal verb',
        translation: 'с нетерпением ждать',
        exampleEn: 'I really look forward to seeing you next weekend.',
        exampleRu: 'Я очень жду встречи с тобой на следующих выходных.',
        secondaryExampleEn: 'We are looking forward to our summer holiday.',
        secondaryExampleRu: 'Мы с нетерпением ждём нашего летнего отпуска.',
        cefrLevel: 'B1',
        imageUrl: STARTER_WORD_IMAGES['look forward to'],
      },
    ],
  },
  {
    key: 'b2-upper-intermediate',
    title: 'Уверенное общение и карьера (B2)',
    description: 'Точная лексика уровня Upper-Intermediate для переговоров, аналитики и свободной речи.',
    category: 'Карьера и дискуссии',
    cefrLevel: 'B2',
    words: [
      {
        word: 'resilient',
        phonetic: '/rɪˈzɪl.jənt/',
        partOfSpeech: 'adjective',
        translation: 'стойкий, жизнестойкий',
        exampleEn: 'Small teams often stay remarkably resilient during rapid change.',
        exampleRu: 'Небольшие команды часто сохраняют удивительную стойкость во время быстрых перемен.',
        secondaryExampleEn: 'Building resilient habits takes daily consistency.',
        secondaryExampleRu: 'Формирование устойчивых привычек требует ежедневного постоянства.',
        cefrLevel: 'B2',
        imageUrl: STARTER_WORD_IMAGES.resilient,
      },
      {
        word: 'perspective',
        phonetic: '/pəˈspek.tɪv/',
        partOfSpeech: 'noun',
        translation: 'точка зрения, перспектива',
        exampleEn: 'Living abroad gave me a fresh perspective on daily routines.',
        exampleRu: 'Жизнь за границей подарила мне свежий взгляд на повседневные привычки.',
        secondaryExampleEn: 'Try looking at the issue from the client’s perspective.',
        secondaryExampleRu: 'Попробуйте взглянуть на вопрос с точки зрения клиента.',
        cefrLevel: 'B2',
        imageUrl: STARTER_WORD_IMAGES.perspective,
      },
      {
        word: 'collaborate',
        phonetic: '/kəˈlæb.ə.reɪt/',
        partOfSpeech: 'verb',
        translation: 'сотрудничать, работать совместно',
        exampleEn: 'Designers and engineers collaborate closely on every release.',
        exampleRu: 'Дизайнеры и инженеры тесно сотрудничают над каждым релизом.',
        secondaryExampleEn: 'Two universities agreed to collaborate on climate research.',
        secondaryExampleRu: 'Два университета договорились о совместном исследовании климата.',
        cefrLevel: 'B2',
        imageUrl: STARTER_WORD_IMAGES.collaborate,
      },
      {
        word: 'efficient',
        phonetic: '/ɪˈfɪʃ.ənt/',
        partOfSpeech: 'adjective',
        translation: 'эффективный, рациональный',
        exampleEn: 'Spaced repetition is a highly efficient method for memorizing words.',
        exampleRu: 'Интервальное повторение — очень эффективный метод запоминания слов.',
        secondaryExampleEn: 'The new high-speed train makes commuting much more efficient.',
        secondaryExampleRu: 'Новый скоростной поезд делает поездки гораздо эффективнее.',
        cefrLevel: 'B2',
        imageUrl: STARTER_WORD_IMAGES.efficient,
      },
      {
        word: 'negotiate',
        phonetic: '/nɪˈɡəʊ.ʃi.eɪt/',
        partOfSpeech: 'verb',
        translation: 'вести переговоры, договариваться',
        exampleEn: 'They plan to negotiate better terms with the supplier next week.',
        exampleRu: 'На следующей неделе они планируют согласовать более выгодные условия с поставщиком.',
        secondaryExampleEn: 'Learning how to negotiate calmly helps in any career.',
        secondaryExampleRu: 'Умение спокойно вести переговоры помогает в любой карьере.',
        cefrLevel: 'B2',
        imageUrl: STARTER_WORD_IMAGES.negotiate,
      },
      {
        word: 'sustainable',
        phonetic: '/səˈsteɪ.nə.bəl/',
        partOfSpeech: 'adjective',
        translation: 'устойчивый, экологичный',
        exampleEn: 'Many cities are investing in sustainable wind and solar energy.',
        exampleRu: 'Многие города инвестируют в устойчивую ветровую и солнечную энергетику.',
        secondaryExampleEn: 'Twenty minutes of study a day is a sustainable pace.',
        secondaryExampleRu: 'Двадцать минут занятий в день — это устойчивый темп.',
        cefrLevel: 'B2',
        imageUrl: STARTER_WORD_IMAGES.sustainable,
      },
    ],
  },
  {
    key: 'c1-advanced',
    title: 'Академический и продвинутый (C1)',
    description: 'Выразительная лексика продвинутого уровня для эссе, выступлений и беглой речи.',
    category: 'Продвинутый уровень',
    cefrLevel: 'C1',
    words: [
      {
        word: 'ubiquitous',
        phonetic: '/juːˈbɪk.wɪ.təs/',
        partOfSpeech: 'adjective',
        translation: 'повсеместный, вездесущий',
        exampleEn: 'Smartphones have become ubiquitous in modern urban life.',
        exampleRu: 'Смартфоны стали повсеместными в современной городской жизни.',
        secondaryExampleEn: 'Contactless payments are now ubiquitous across Europe.',
        secondaryExampleRu: 'Бесконтактная оплата сейчас распространена повсеместно по всей Европе.',
        cefrLevel: 'C1',
        imageUrl: STARTER_WORD_IMAGES.ubiquitous,
      },
      {
        word: 'ambiguous',
        phonetic: '/æmˈbɪɡ.ju.əs/',
        partOfSpeech: 'adjective',
        translation: 'двусмысленный, неоднозначный',
        exampleEn: 'The wording of the contract sounded deliberately ambiguous.',
        exampleRu: 'Формулировка договора звучала намеренно двусмысленно.',
        secondaryExampleEn: 'Avoid ambiguous phrases when writing technical documentation.',
        secondaryExampleRu: 'Избегайте неоднозначных фраз при написании технической документации.',
        cefrLevel: 'C1',
        imageUrl: STARTER_WORD_IMAGES.ambiguous,
      },
      {
        word: 'scrutinize',
        phonetic: '/ˈskruː.tɪ.naɪz/',
        partOfSpeech: 'verb',
        translation: 'тщательно изучать, проверять',
        exampleEn: 'Analysts scrutinize every quarterly report before making forecasts.',
        exampleRu: 'Аналитики тщательно изучают каждый квартальный отчёт перед составлением прогнозов.',
        secondaryExampleEn: 'He scrutinized the small print on the ticket.',
        secondaryExampleRu: 'Он внимательно изучил мелкий шрифт на билете.',
        cefrLevel: 'C1',
        imageUrl: STARTER_WORD_IMAGES.scrutinize,
      },
      {
        word: 'pragmatic',
        phonetic: '/præɡˈmæt.ɪk/',
        partOfSpeech: 'adjective',
        translation: 'прагматичный, практичный',
        exampleEn: 'She offered a pragmatic solution that could be shipped in two days.',
        exampleRu: 'Она предложила прагматичное решение, которое можно выпустить за два дня.',
        secondaryExampleEn: 'We need a pragmatic approach to budgeting this quarter.',
        secondaryExampleRu: 'Нам нужен прагматичный подход к бюджету в этом квартале.',
        cefrLevel: 'C1',
        imageUrl: STARTER_WORD_IMAGES.pragmatic,
      },
      {
        word: 'ephemeral',
        phonetic: '/ɪˈfem.ər.əl/',
        partOfSpeech: 'adjective',
        translation: 'мимолётный, недолговечный',
        exampleEn: 'Cherry blossoms are famous for their ephemeral spring beauty.',
        exampleRu: 'Цветение сакуры знаменито своей мимолётной весенней красотой.',
        secondaryExampleEn: 'Online trends are often ephemeral compared with classic books.',
        secondaryExampleRu: 'Онлайн-тренды часто мимолётны по сравнению с классическими книгами.',
        cefrLevel: 'C1',
        imageUrl: STARTER_WORD_IMAGES.ephemeral,
      },
      {
        word: 'eloquent',
        phonetic: '/ˈel.ə.kwənt/',
        partOfSpeech: 'adjective',
        translation: 'красноречивый, выразительный',
        exampleEn: 'She delivered an eloquent speech at the international summit.',
        exampleRu: 'Она произнесла красноречивую речь на международном саммите.',
        secondaryExampleEn: 'His essays are concise, clear, and remarkably eloquent.',
        secondaryExampleRu: 'Его эссе лаконичны, ясны и удивительно выразительны.',
        cefrLevel: 'C1',
        imageUrl: STARTER_WORD_IMAGES.eloquent,
      },
    ],
  },
];

export function normalizeCefrLevel(raw: unknown): CefrLevel {
  const upper = String(raw || '').trim().toUpperCase();
  if (upper === 'A1' || upper === 'A2' || upper === 'B1' || upper === 'B2' || upper === 'C1') {
    return upper;
  }
  return 'A2';
}

export function getCuratedDecksForLevel(level: CefrLevel): CuratedDeckSpec[] {
  const exact = CURATED_DECKS_CATALOG.filter((d) => d.cefrLevel === level);
  return exact.length > 0 ? exact : [CURATED_DECKS_CATALOG[1]];
}
